<nav id="left_nav">
    <a class='nav_link' href="display_products.php">PRODUCTS</a>
      <a href="display_category.php" class='nav_link'>CATEGORY</a>
      <a href="display_color.php" class='nav_link'>COLOR</a>
      <a href="display_size.php" class='nav_link'>SIZE</a>
      <a href="display_febric.php" class='nav_link'>FEBRIC</a>
      <a href="display_type.php" class='nav_link'>TYPE</a>
      <a href="display_customer.php" class='nav_link'>CUSTOMER</a>
      <a href="display_employee.php" class='nav_link'>EMPLOYEE</a>
      <a href="display_order.php" class='nav_link'>ORDER</a>
    </nav>